/*
	Jaime Eugenio Garcia
	JEG3954
*/

#include <assert.h>
#include "Parse.h"
#include "handler.h"

int main(){
	set_input("test_grader.blip");
    run();
	return 0;
}
