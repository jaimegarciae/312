//
// Created by Vallath Nandakumar on 3/16/17.
//

#ifndef INSERTIONSORT_SORT_FUNCTIONS_H
#define INSERTIONSORT_SORT_FUNCTIONS_H
void insertion_sort(int* a, int size);
void fun1(int *a, int size);
#endif //INSERTIONSORT_SORT_FUNCTIONS_H
